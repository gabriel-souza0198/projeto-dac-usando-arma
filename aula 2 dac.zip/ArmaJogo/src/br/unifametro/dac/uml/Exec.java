package br.unifametro.dac.uml;

public class Exec {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

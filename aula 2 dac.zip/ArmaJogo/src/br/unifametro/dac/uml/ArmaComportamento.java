package br.unifametro.dac.uml;

public interface ArmaComportamento {
	public void usarArma();
	

}

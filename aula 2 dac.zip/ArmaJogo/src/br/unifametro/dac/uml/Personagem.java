package br.unifametro.dac.uml;

public class Personagem {
	private ArmaComportamento armaComportamento;
	
	public void lutar(String txt) {
		System.out.println(txt);
	}

	public ArmaComportamento getArmaComportamento() {
		return armaComportamento;
	}

	public void setArmaComportamento(ArmaComportamento armaComportamento) {
		this.armaComportamento = armaComportamento;
	}
	
}

package br.unifametro.dac.uml;

public class Cavaleiro extends Personagem{
	
	@Override
	public void lutar(String txt) {
		// TODO Auto-generated method stub
		super.lutar(txt);
	}


}

package br.unifametro.dac.uml;

public class FacaComportamento {

}
